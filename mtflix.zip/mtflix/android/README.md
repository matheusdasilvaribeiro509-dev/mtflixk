# MT FLIX — Android

O app Android reaproveita o mesmo site (React) dentro de um "casco" nativo, usando o
[Capacitor](https://capacitorjs.com/). Assim você mantém **um catálogo, um sistema de login e
uma API só** para o site e para o Android — exatamente como pedido.

Pré-requisitos na sua máquina: Node.js, Android Studio instalado, e o site (`web/`) já rodando
ou publicado em algum endereço (ex.: `https://api.seudominio.com`).

## Passo a passo

1. Entre na pasta do site:
   ```bash
   cd web
   npm install
   npm install @capacitor/core @capacitor/android
   npm install -D @capacitor/cli
   ```

2. Gere a versão de produção do site:
   ```bash
   npm run build
   ```

3. Inicialize o Capacitor (uma única vez):
   ```bash
   npx cap init "MT FLIX" "com.mtflix.app" --web-dir=dist
   ```

4. Antes do build final, aponte a API para o endereço público do seu servidor (não use
   `localhost`, pois o celular não enxerga o seu computador). Edite `web/src/api.ts` e troque:
   ```ts
   const BASE = "/api";
   ```
   por algo como:
   ```ts
   const BASE = "https://api.seudominio.com/api";
   ```
   Rode `npm run build` de novo depois dessa troca.

5. Adicione a plataforma Android e abra no Android Studio:
   ```bash
   npx cap add android
   npx cap copy
   npx cap open android
   ```

6. No Android Studio: `Build > Generate Signed Bundle / APK`, siga o passo de criar (ou usar)
   uma chave de assinatura, e gere o APK. É esse APK que você instala no celular ou envia para
   a Play Store.

## Mantendo o app atualizado

Sempre que mudar algo no site (`web/`), repita: `npm run build` → `npx cap copy` → gerar o APK
de novo no Android Studio. O catálogo, login e favoritos continuam vindo da mesma API — não
precisa duplicar nada.

## Alternativa mais simples

Se só precisar de algo rápido para testar no celular, sem gerar APK, você pode:
- Publicar o site (`web/`) em qualquer hospedagem (Vercel, Netlify, etc.);
- Abrir o endereço no navegador do celular e usar "Adicionar à tela inicial" — isso já cria um
  ícone com aparência de app, sem precisar do Android Studio.
