import { Router } from "express";
import bcrypt from "bcryptjs";
import { v4 as uuid } from "uuid";
import { db } from "../db";
import { signToken, requireAuth, AuthedRequest } from "../auth";
import { User } from "../types";

export const authRouter = Router();

authRouter.post("/register", async (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Preencha nome, e-mail e senha." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "A senha precisa ter ao menos 6 caracteres." });
  }
  const emailNorm = String(email).trim().toLowerCase();
  const exists = db.get("users").find({ email: emailNorm }).value();
  if (exists) return res.status(409).json({ error: "Já existe uma conta com esse e-mail." });

  const user: User = {
    id: uuid(),
    name: String(name).trim(),
    email: emailNorm,
    passwordHash: await bcrypt.hash(password, 10),
    isAdmin: false,
    createdAt: new Date().toISOString(),
  };
  db.get("users").push(user).write();

  const token = signToken({ id: user.id, email: user.email, isAdmin: user.isAdmin });
  res.status(201).json({ token, user: { id: user.id, name: user.name, email: user.email, isAdmin: user.isAdmin } });
});

authRouter.post("/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "Informe e-mail e senha." });

  const user = db.get("users").find({ email: String(email).trim().toLowerCase() }).value();
  if (!user) return res.status(401).json({ error: "E-mail ou senha incorretos." });

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: "E-mail ou senha incorretos." });

  const token = signToken({ id: user.id, email: user.email, isAdmin: user.isAdmin });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, isAdmin: user.isAdmin } });
});

authRouter.get("/me", requireAuth, (req: AuthedRequest, res) => {
  const user = db.get("users").find({ id: req.user!.id }).value();
  if (!user) return res.status(404).json({ error: "Usuário não encontrado." });
  res.json({ id: user.id, name: user.name, email: user.email, isAdmin: user.isAdmin });
});
