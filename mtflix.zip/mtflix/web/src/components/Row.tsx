import { Title } from "../api";
import Card from "./Card";

export default function Row({
  title,
  items,
  progressMap,
}: {
  title: string;
  items: Title[];
  progressMap?: Record<string, number>;
}) {
  if (items.length === 0) return null;
  return (
    <section className="row">
      <div className="row-head"><h2 className="row-title">{title}</h2></div>
      <div className="row-track">
        {items.map((t) => (
          <Card key={t.id} title={t} progressPct={progressMap?.[t.id]} />
        ))}
      </div>
    </section>
  );
}
