import { FormEvent, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  function onSearch(e: FormEvent) {
    e.preventDefault();
    if (q.trim()) navigate(`/busca?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <header className="nav">
      <div className="nav-inner">
        <Link to="/" className="brand"><span className="mt">MT</span><span className="flix">FLIX</span></Link>

        <nav className="nav-links">
          <NavLink to="/" end>Início</NavLink>
          <NavLink to="/categoria/acao">Ação</NavLink>
          <NavLink to="/categoria/terror">Terror</NavLink>
          <NavLink to="/categoria/comedia">Comédia</NavLink>
          <NavLink to="/categoria/animes">Animes</NavLink>
          <NavLink to="/categoria/desenhos">Desenhos</NavLink>
          {user && <NavLink to="/minha-lista">Minha lista</NavLink>}
          {user?.isAdmin && <NavLink to="/admin">Admin</NavLink>}
        </nav>

        <form className="nav-search" onSubmit={onSearch}>
          <span aria-hidden>🔍</span>
          <input
            placeholder="Títulos, gêneros..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </form>

        <div className="nav-user">
          {user ? (
            <>
              <div className="avatar" title={user.name}>{user.name[0]?.toUpperCase()}</div>
              <button className="btn btn-ghost" onClick={logout}>Sair</button>
            </>
          ) : (
            <Link to="/entrar" className="btn btn-primary">Entrar</Link>
          )}
        </div>
      </div>
    </header>
  );
}
