import { useNavigate } from "react-router-dom";
import { Title } from "../api";
import { CATEGORIES } from "../api";

export default function Hero({ title }: { title: Title }) {
  const navigate = useNavigate();
  const categoryLabel = CATEGORIES.find((c) => c.value === title.category)?.label ?? title.category;

  return (
    <section className="hero">
      <div className="hero-bg" style={{ backgroundImage: `url(${title.bannerUrl})` }} />
      <div className="hero-content">
        <p className="hero-badge">Em destaque · {categoryLabel}</p>
        <h1 className="hero-title">{title.title}</h1>
        <p className="hero-synopsis">{title.synopsis}</p>
        <div className="hero-actions">
          <button className="btn btn-primary" onClick={() => navigate(`/assistir/${title.id}`)}>▶ Assistir</button>
          <button className="btn btn-ghost" onClick={() => navigate(`/titulo/${title.id}`)}>Mais informações</button>
        </div>
      </div>
    </section>
  );
}
