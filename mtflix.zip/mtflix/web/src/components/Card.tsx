import { useNavigate } from "react-router-dom";
import { Title } from "../api";

export default function Card({ title, progressPct }: { title: Title; progressPct?: number }) {
  const navigate = useNavigate();
  return (
    <div className="card" onClick={() => navigate(`/titulo/${title.id}`)}>
      <img className="card-poster" src={title.posterUrl} alt={title.title} loading="lazy" />
      <div className="card-body">
        <p className="card-title">{title.title}</p>
        <div className="card-meta">
          <span>{title.year}</span>
          <span className="pill">★ {title.rating.toFixed(1)}</span>
        </div>
        {typeof progressPct === "number" && (
          <div className="progress-bar"><span style={{ width: `${Math.min(progressPct, 100)}%` }} /></div>
        )}
      </div>
    </div>
  );
}
