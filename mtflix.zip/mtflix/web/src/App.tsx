import { Route, Routes, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import { RequireAuth, RequireAdmin } from "./components/ProtectedRoute";
import Home from "./pages/Home";
import Browse from "./pages/Browse";
import Search from "./pages/Search";
import TitleDetail from "./pages/TitleDetail";
import Player from "./pages/Player";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Favorites from "./pages/Favorites";
import Profile from "./pages/Profile";
import Admin from "./pages/Admin";

export default function App() {
  const location = useLocation();
  const isPlayer = location.pathname.startsWith("/assistir/");
  const isAuthScreen = ["/entrar", "/cadastro"].includes(location.pathname);

  return (
    <>
      {!isPlayer && !isAuthScreen && <Navbar />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/categoria/:category" element={<Browse />} />
        <Route path="/busca" element={<Search />} />
        <Route path="/titulo/:id" element={<TitleDetail />} />
        <Route path="/assistir/:id" element={<Player />} />
        <Route path="/entrar" element={<Login />} />
        <Route path="/cadastro" element={<Register />} />
        <Route path="/minha-lista" element={<RequireAuth><Favorites /></RequireAuth>} />
        <Route path="/perfil" element={<RequireAuth><Profile /></RequireAuth>} />
        <Route path="/admin" element={<RequireAdmin><Admin /></RequireAdmin>} />
        <Route path="*" element={<div className="empty-state">Página não encontrada.</div>} />
      </Routes>
      {!isPlayer && !isAuthScreen && (
        <footer className="footer">
          MT FLIX — catálogo de obras em domínio público ou com autorização de distribuição. Verifique a licença de cada título antes de publicar novos conteúdos.
        </footer>
      )}
    </>
  );
}
