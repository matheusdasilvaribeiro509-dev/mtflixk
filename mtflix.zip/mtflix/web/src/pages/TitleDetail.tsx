import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, CATEGORIES, Title } from "../api";
import { useAuth } from "../context/AuthContext";

export default function TitleDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [title, setTitle] = useState<Title | null>(null);
  const [isFav, setIsFav] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!id) return;
    api.title(id).then(setTitle);
    if (user) api.favorites().then((favs) => setIsFav(favs.some((f) => f.id === id)));
  }, [id, user]);

  async function toggleFavorite() {
    if (!user) return navigate("/entrar");
    if (!id) return;
    setBusy(true);
    try {
      if (isFav) { await api.removeFavorite(id); setIsFav(false); }
      else { await api.addFavorite(id); setIsFav(true); }
    } finally { setBusy(false); }
  }

  if (!title) return <div className="loading">Carregando...</div>;
  const categoryLabel = CATEGORIES.find((c) => c.value === title.category)?.label ?? title.category;

  return (
    <div>
      <div className="detail-hero">
        <div className="hero-bg" style={{ backgroundImage: `url(${title.bannerUrl})` }} />
      </div>
      <div className="detail-body">
        <div className="detail-head">
          <img className="detail-poster" src={title.posterUrl} alt={title.title} />
          <div>
            <h1 className="hero-title" style={{ fontSize: "clamp(26px,4vw,40px)" }}>{title.title}</h1>
            <div className="detail-meta">
              <span>{title.year}</span>
              <span>{title.durationMinutes} min</span>
              <span className="pill">★ {title.rating.toFixed(1)}</span>
              <span>{categoryLabel}</span>
            </div>
            <div className="hero-actions">
              <button className="btn btn-primary" onClick={() => navigate(`/assistir/${title.id}`)}>▶ Assistir</button>
              <button className="btn btn-outline" onClick={toggleFavorite} disabled={busy}>
                {isFav ? "✓ Na minha lista" : "+ Minha lista"}
              </button>
            </div>
          </div>
        </div>
        <p className="detail-synopsis">{title.synopsis}</p>
      </div>
    </div>
  );
}
