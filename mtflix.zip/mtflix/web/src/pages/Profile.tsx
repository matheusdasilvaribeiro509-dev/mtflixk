import { useAuth } from "../context/AuthContext";

// Perfil simples da conta logada. O catálogo e o histórico hoje são por conta — para evoluir
// para múltiplos perfis por conta (como a Netflix), crie uma tabela "profiles" ligada ao userId
// e passe o profileId selecionado nas chamadas de favoritos/histórico.
export default function Profile() {
  const { user, logout } = useAuth();
  if (!user) return null;

  return (
    <div className="wrap" style={{ paddingTop: 48, paddingBottom: 60, maxWidth: 480 }}>
      <div className="profile-tile" style={{ width: 96, marginBottom: 20 }}>
        <div className="profile-avatar">{user.name[0]?.toUpperCase()}</div>
      </div>
      <h1 style={{ fontSize: 24, margin: "0 0 4px" }}>{user.name}</h1>
      <p style={{ color: "var(--muted)", margin: "0 0 24px" }}>{user.email}</p>
      {user.isAdmin && <p className="pill" style={{ display: "inline-block", marginBottom: 24 }}>Administrador</p>}
      <div><button className="btn btn-outline" onClick={logout}>Sair da conta</button></div>
    </div>
  );
}
