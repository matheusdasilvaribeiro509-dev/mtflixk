import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { api, Title } from "../api";
import Card from "../components/Card";

export default function Search() {
  const [params] = useSearchParams();
  const q = params.get("q") || "";
  const [items, setItems] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!q) { setItems([]); setLoading(false); return; }
    setLoading(true);
    api.titles({ q }).then((t) => { setItems(t); setLoading(false); });
  }, [q]);

  return (
    <div className="wrap" style={{ paddingTop: 32, paddingBottom: 60 }}>
      <h1 className="row-title" style={{ fontSize: 22, marginBottom: 20 }}>
        Resultados para "{q}"
      </h1>
      {loading ? (
        <div className="loading">Buscando...</div>
      ) : items.length === 0 ? (
        <div className="empty-state">Nada encontrado. Tente outro termo.</div>
      ) : (
        <div className="grid">{items.map((t) => <Card key={t.id} title={t} />)}</div>
      )}
    </div>
  );
}
