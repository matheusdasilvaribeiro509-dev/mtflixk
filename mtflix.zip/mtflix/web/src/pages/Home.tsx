import { useEffect, useState } from "react";
import { api, CATEGORIES, HistoryItem, Title } from "../api";
import { useAuth } from "../context/AuthContext";
import Hero from "../components/Hero";
import Row from "../components/Row";

export default function Home() {
  const { user } = useAuth();
  const [featured, setFeatured] = useState<Title[]>([]);
  const [byCategory, setByCategory] = useState<Record<string, Title[]>>({});
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    async function load() {
      const [feat, ...cats] = await Promise.all([
        api.featured(),
        ...CATEGORIES.map((c) => api.titles({ category: c.value })),
      ]);
      if (!active) return;
      setFeatured(feat);
      const map: Record<string, Title[]> = {};
      CATEGORIES.forEach((c, i) => (map[c.value] = cats[i]));
      setByCategory(map);
      if (user) {
        try { setHistory(await api.history()); } catch { /* sem histórico ainda */ }
      }
      setLoading(false);
    }
    load();
    return () => { active = false; };
  }, [user]);

  if (loading) return <div className="loading">Carregando catálogo...</div>;

  const hero = featured[0];
  const progressMap: Record<string, number> = {};
  history.forEach((h) => { progressMap[h.titleId] = (h.progressSeconds / h.durationSeconds) * 100; });

  return (
    <div>
      {hero && <Hero title={hero} />}
      <div style={{ marginTop: hero ? -60 : 32, position: "relative" }}>
        {history.length > 0 && (
          <Row title="Continuar assistindo" items={history.map((h) => h.title)} progressMap={progressMap} />
        )}
        {featured.length > 1 && <Row title="Em destaque" items={featured} />}
        {CATEGORIES.map((c) => (
          <Row key={c.value} title={c.label} items={byCategory[c.value] || []} />
        ))}
      </div>
    </div>
  );
}
