import { FormEvent, useEffect, useState } from "react";
import { api, CATEGORIES, Title } from "../api";

const empty: Partial<Title> = {
  title: "", synopsis: "", year: new Date().getFullYear(), category: "acao",
  posterUrl: "", bannerUrl: "", videoUrl: "", durationMinutes: 90, rating: 7, featured: false, source: "",
};

export default function Admin() {
  const [titles, setTitles] = useState<Title[]>([]);
  const [form, setForm] = useState<Partial<Title>>(empty);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [ok, setOk] = useState("");
  const [loading, setLoading] = useState(true);

  function load() { api.adminTitles().then((t) => { setTitles(t); setLoading(false); }); }
  useEffect(load, []);

  function onEdit(t: Title) { setEditingId(t.id); setForm(t); setOk(""); setError(""); }
  function onNew() { setEditingId(null); setForm(empty); setOk(""); setError(""); }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(""); setOk("");
    try {
      if (editingId) {
        await api.adminUpdateTitle(editingId, form);
        setOk("Título atualizado.");
      } else {
        await api.adminCreateTitle(form);
        setOk("Título criado.");
      }
      onNew();
      load();
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function onDelete(id: string) {
    if (!confirm("Remover este título do catálogo?")) return;
    await api.adminDeleteTitle(id);
    load();
  }

  function setField<K extends keyof Title>(key: K, value: Title[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  return (
    <div className="admin-layout">
      <h1 style={{ fontSize: 24, marginBottom: 4 }}>Painel administrativo</h1>
      <p style={{ color: "var(--muted)", marginBottom: 28 }}>Gerencie o catálogo: capas, descrições e links de vídeo.</p>

      <div className="auth-card" style={{ maxWidth: "none", marginBottom: 36 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 16px" }}>{editingId ? "Editar título" : "Novo título"}</h2>
        {error && <div className="form-error">{error}</div>}
        {ok && <div className="form-ok">{ok}</div>}
        <form onSubmit={onSubmit} className="admin-grid-form">
          <div className="field"><label>Título</label>
            <input required value={form.title || ""} onChange={(e) => setField("title", e.target.value)} /></div>
          <div className="field"><label>Ano</label>
            <input type="number" required value={form.year || ""} onChange={(e) => setField("year", Number(e.target.value))} /></div>

          <div className="field full"><label>Sinopse</label>
            <textarea rows={3} required value={form.synopsis || ""} onChange={(e) => setField("synopsis", e.target.value)} /></div>

          <div className="field"><label>Categoria</label>
            <select value={form.category || "acao"} onChange={(e) => setField("category", e.target.value as Title["category"])}>
              {CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select></div>
          <div className="field"><label>Duração (min)</label>
            <input type="number" value={form.durationMinutes || 0} onChange={(e) => setField("durationMinutes", Number(e.target.value))} /></div>

          <div className="field"><label>Nota (0-10)</label>
            <input type="number" step="0.1" min={0} max={10} value={form.rating ?? 0} onChange={(e) => setField("rating", Number(e.target.value))} /></div>
          <div className="field" style={{ justifyContent: "center", flexDirection: "row", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="featured" checked={!!form.featured} onChange={(e) => setField("featured", e.target.checked)} style={{ width: 16, height: 16 }} />
            <label htmlFor="featured" style={{ margin: 0 }}>Destacar na página inicial</label>
          </div>

          <div className="field full"><label>URL do pôster (vertical)</label>
            <input required value={form.posterUrl || ""} onChange={(e) => setField("posterUrl", e.target.value)} /></div>
          <div className="field full"><label>URL do banner (horizontal, para o topo)</label>
            <input required value={form.bannerUrl || ""} onChange={(e) => setField("bannerUrl", e.target.value)} /></div>
          <div className="field full"><label>URL do vídeo (.mp4 com autorização de distribuição)</label>
            <input required value={form.videoUrl || ""} onChange={(e) => setField("videoUrl", e.target.value)} /></div>
          <div className="field full"><label>Fonte / licença (anotação interna)</label>
            <input value={form.source || ""} onChange={(e) => setField("source", e.target.value)} placeholder="Ex.: Domínio público — Archive.org, identifier X" /></div>

          <div className="field full" style={{ flexDirection: "row", gap: 10 }}>
            <button className="btn btn-primary">{editingId ? "Salvar alterações" : "Adicionar título"}</button>
            {editingId && <button type="button" className="btn btn-ghost" onClick={onNew}>Cancelar</button>}
          </div>
        </form>
      </div>

      <h2 style={{ fontSize: 17, margin: "0 0 14px" }}>Catálogo ({titles.length})</h2>
      {loading ? <div className="loading">Carregando...</div> : (
        <table className="admin-table">
          <thead><tr><th>Título</th><th>Categoria</th><th>Ano</th><th>Destaque</th><th></th></tr></thead>
          <tbody>
            {titles.map((t) => (
              <tr key={t.id}>
                <td>{t.title}</td>
                <td>{CATEGORIES.find((c) => c.value === t.category)?.label}</td>
                <td>{t.year}</td>
                <td>{t.featured ? "Sim" : "—"}</td>
                <td style={{ display: "flex", gap: 8 }}>
                  <button className="btn btn-outline" onClick={() => onEdit(t)}>Editar</button>
                  <button className="btn btn-danger" onClick={() => onDelete(t.id)}>Excluir</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
