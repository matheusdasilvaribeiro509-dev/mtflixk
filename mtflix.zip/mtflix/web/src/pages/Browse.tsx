import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api, CATEGORIES, Title } from "../api";
import Card from "../components/Card";

export default function Browse() {
  const { category } = useParams();
  const [items, setItems] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);
  const label = CATEGORIES.find((c) => c.value === category)?.label ?? category;

  useEffect(() => {
    setLoading(true);
    api.titles({ category }).then((t) => { setItems(t); setLoading(false); });
  }, [category]);

  return (
    <div className="wrap" style={{ paddingTop: 32, paddingBottom: 60 }}>
      <h1 className="row-title" style={{ fontSize: 26, marginBottom: 20 }}>{label}</h1>
      {loading ? (
        <div className="loading">Carregando...</div>
      ) : items.length === 0 ? (
        <div className="empty-state">Ainda não há títulos nessa categoria.</div>
      ) : (
        <div className="grid">{items.map((t) => <Card key={t.id} title={t} />)}</div>
      )}
    </div>
  );
}
