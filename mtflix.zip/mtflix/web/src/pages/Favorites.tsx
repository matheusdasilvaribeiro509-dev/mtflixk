import { useEffect, useState } from "react";
import { api, Title } from "../api";
import Card from "../components/Card";

export default function Favorites() {
  const [items, setItems] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { api.favorites().then((t) => { setItems(t); setLoading(false); }); }, []);

  return (
    <div className="wrap" style={{ paddingTop: 32, paddingBottom: 60 }}>
      <h1 className="row-title" style={{ fontSize: 26, marginBottom: 20 }}>Minha lista</h1>
      {loading ? (
        <div className="loading">Carregando...</div>
      ) : items.length === 0 ? (
        <div className="empty-state">Você ainda não adicionou nenhum título. Toque em "+ Minha lista" na página de um título.</div>
      ) : (
        <div className="grid">{items.map((t) => <Card key={t.id} title={t} />)}</div>
      )}
    </div>
  );
}
