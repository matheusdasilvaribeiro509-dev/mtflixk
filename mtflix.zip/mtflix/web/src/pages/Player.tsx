import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api, Title } from "../api";
import { useAuth } from "../context/AuthContext";

export default function Player() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [title, setTitle] = useState<Title | null>(null);
  const [resumeAt, setResumeAt] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const lastSaved = useRef(0);

  useEffect(() => {
    if (!id) return;
    api.title(id).then(setTitle);
    if (user) {
      api.history().then((h) => {
        const entry = h.find((e) => e.titleId === id);
        if (entry && entry.progressSeconds < entry.durationSeconds - 15) {
          setResumeAt(entry.progressSeconds);
        }
      });
    }
  }, [id, user]);

  function onLoadedMetadata() {
    if (videoRef.current && resumeAt > 0) videoRef.current.currentTime = resumeAt;
  }

  function onTimeUpdate() {
    const v = videoRef.current;
    if (!v || !user || !id) return;
    // Salva o progresso no máximo a cada 5 segundos, para não sobrecarregar a API.
    if (v.currentTime - lastSaved.current >= 5) {
      lastSaved.current = v.currentTime;
      api.saveProgress(id, Math.floor(v.currentTime), Math.floor(v.duration || 0)).catch(() => {});
    }
  }

  function onEnded() {
    const v = videoRef.current;
    if (!v || !user || !id) return;
    api.saveProgress(id, Math.floor(v.duration || 0), Math.floor(v.duration || 0)).catch(() => {});
  }

  if (!title) return <div className="loading">Carregando...</div>;

  return (
    <div>
      <div className="player-wrap">
        <video
          ref={videoRef}
          src={title.videoUrl}
          controls
          autoPlay
          onLoadedMetadata={onLoadedMetadata}
          onTimeUpdate={onTimeUpdate}
          onEnded={onEnded}
        />
      </div>
      <div className="player-bar">
        <button className="btn btn-ghost" onClick={() => navigate(`/titulo/${title.id}`)}>← Voltar</button>
        <strong>{title.title}</strong>
        <span />
      </div>
    </div>
  );
}
