import { FormEvent, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      await login(email, password);
      navigate("/");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-screen">
      <div className="auth-card">
        <Link to="/" className="brand" style={{ display: "block", marginBottom: 24 }}>
          <span className="mt">MT</span><span className="flix">FLIX</span>
        </Link>
        <h1 style={{ fontSize: 22, margin: "0 0 20px" }}>Entrar</h1>
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={onSubmit}>
          <div className="field">
            <label>E-mail</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="field">
            <label>Senha</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <button className="btn btn-primary" style={{ width: "100%", justifyContent: "center" }} disabled={busy}>
            {busy ? "Entrando..." : "Entrar"}
          </button>
        </form>
        <p style={{ color: "var(--muted)", fontSize: 13, marginTop: 18 }}>
          Novo na MT FLIX? <Link to="/cadastro" style={{ color: "var(--brand-2)" }}>Criar conta</Link>
        </p>
      </div>
    </div>
  );
}
